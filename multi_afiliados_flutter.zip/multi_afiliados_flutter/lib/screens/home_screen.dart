
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import './lista_produtos_screen.dart';
import '../providers/produto_provider.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final produtos = Provider.of<ProdutoProvider>(context).produtos;
    final categorias = produtos.map((p) => p.categoria).toSet().toList();

    return Scaffold(
      appBar: AppBar(title: Text('MultiAfiliados')),
      body: ListView.builder(
        itemCount: categorias.length,
        itemBuilder: (ctx, i) => ListTile(
          title: Text(categorias[i]),
          onTap: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => ListaProdutosScreen(
                  categoria: categorias[i],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
