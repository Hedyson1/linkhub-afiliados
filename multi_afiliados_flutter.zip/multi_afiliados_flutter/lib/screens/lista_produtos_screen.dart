
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/produto_provider.dart';
import './detalhe_produto_screen.dart';

class ListaProdutosScreen extends StatelessWidget {
  final String categoria;

  ListaProdutosScreen({required this.categoria});

  @override
  Widget build(BuildContext context) {
    final produtos = Provider.of<ProdutoProvider>(context)
        .produtos
        .where((p) => p.categoria == categoria)
        .toList();

    return Scaffold(
      appBar: AppBar(title: Text(categoria)),
      body: ListView.builder(
        itemCount: produtos.length,
        itemBuilder: (ctx, i) => ListTile(
          leading: Image.network(produtos[i].imagemUrl, width: 50),
          title: Text(produtos[i].nome),
          onTap: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => DetalheProdutoScreen(produto: produtos[i]),
              ),
            );
          },
        ),
      ),
    );
  }
}
