
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../models/produto.dart';

class DetalheProdutoScreen extends StatelessWidget {
  final Produto produto;

  DetalheProdutoScreen({required this.produto});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(produto.nome)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Image.network(produto.imagemUrl),
            SizedBox(height: 16),
            Text(produto.descricao),
            SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: () {
                Share.share(produto.linkAfiliado);
              },
              icon: Icon(Icons.share),
              label: Text('Compartilhar'),
            ),
          ],
        ),
      ),
    );
  }
}
