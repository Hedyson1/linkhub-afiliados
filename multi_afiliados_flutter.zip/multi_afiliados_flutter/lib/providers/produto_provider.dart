
import 'package:flutter/material.dart';
import '../models/produto.dart';

class ProdutoProvider with ChangeNotifier {
  List<Produto> _produtos = [
    Produto(
      categoria: 'Eletrônicos',
      nome: 'Fone Bluetooth',
      descricao: 'Fone com redução de ruído.',
      imagemUrl: 'https://via.placeholder.com/150',
      linkAfiliado: 'https://afiliado.com/link123',
    ),
  ];

  List<Produto> get produtos => [..._produtos];

  void adicionarProduto(Produto produto) {
    _produtos.add(produto);
    notifyListeners();
  }
}
