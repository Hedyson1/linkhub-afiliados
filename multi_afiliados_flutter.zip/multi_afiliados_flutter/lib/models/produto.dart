
class Produto {
  final String categoria;
  final String nome;
  final String descricao;
  final String imagemUrl;
  final String linkAfiliado;

  Produto({
    required this.categoria,
    required this.nome,
    required this.descricao,
    required this.imagemUrl,
    required this.linkAfiliado,
  });
}
