
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import './providers/produto_provider.dart';
import './screens/home_screen.dart';

void main() {
  runApp(MultiAfiliadosApp());
}

class MultiAfiliadosApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => ProdutoProvider(),
      child: MaterialApp(
        title: 'MultiAfiliados',
        theme: ThemeData(primarySwatch: Colors.blue),
        home: HomeScreen(),
      ),
    );
  }
}
