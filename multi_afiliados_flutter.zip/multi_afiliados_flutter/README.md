
# MultiAfiliados Flutter App

Aplicativo para centralizar links de afiliados e compartilhar facilmente.
